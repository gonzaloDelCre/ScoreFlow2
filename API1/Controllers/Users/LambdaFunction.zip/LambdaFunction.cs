﻿namespace API1.Controllers.Users
{
    public class LambdaFunction
    {
    }
}
